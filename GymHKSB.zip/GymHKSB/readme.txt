Gymnasium Höhenkirchen-Siegertsbrunn for Stellarium
==================================

Location
--------

Höhenkirchen-Siegertsbrunn

Latitude:   48° 1′ 0″ N
Longitude:  11° 44′ 0″ E 
Altitude:   586m 


Description
-----------


Licence
-------

(C) 2018 Christoph Krichenbauer, CC-BY-NC-SA-3.0

